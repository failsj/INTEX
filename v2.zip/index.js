const express = require("express");

let app = express();

let path = require("path");

const port = process.env.PORT || 3000;

app.set("view engine", "ejs");

app.use(express.urlencoded({ extended:true}));

const knex = require("knex")({
    client: "pg",
    connection: {
        host: process.env.RDS_HOSTNAME || "localhost",
        user: process.env.RDS_USERNAME || "jakefails",
        password: process.env.RDS_PASSWORD || "admin123",
        database: process.env.RDS_DB_NAME || "bucket_list",
        port: process.env.RDS_PORT || 5432,
        ssl: process.env.DB_SSL ? {rejectUnauthorized: false} : false
    }
});

app.get("/", (req, res) => {
    knex.select().from("country").then( country => {
        res.render("displayCountry", { mycountry : country});
    })
});

app.post("/deleteCountry/:id", (req, res) => {
   knex("country").where("country_id",req.params.id).del().then( mycountry => {
      res.redirect("/");
   }).catch( err => {
      console.log(err);
      res.status(500).json({err});
   });
});

app.listen( port, () => console.log("Server is listening"));